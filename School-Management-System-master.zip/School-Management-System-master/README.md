# School Management System
### This is a Java program to School Management System it is a GUI program by java jframe  and use a Json file.
## Features:
1. The program should allow employee to sign-up and sign-in (with
Employee Name and Employee Password )
2. Add Employee (Manger / Teacher) details.
3. Add Student details.
4. Add Subjects details.
5. Display salaries of Employees.
6. Finding the number of students registered in a particular subject.
7. Sava All details about Employee, Teachers, Students and Subjects to
json file with name "JsonFile.json".

#  To Run this program you need :
https://github.com/mazenaboabda/SchoolManagementSystem/tree/master/dist/lib
### 1. Java JDK 1.8
### 2. json-simple-1.1.jar
### 3. KGradientPanel.jar
