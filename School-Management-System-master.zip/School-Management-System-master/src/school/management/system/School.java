
package school.management.system;

import java.util.ArrayList;
import testframe.*;

public class School {

    
    public static void main(String[] args) {
        ArrayList<Student> student_array= new ArrayList();
        ArrayList<Teacher> teacher_array= new ArrayList();
        ArrayList<Subject> Subject_array= new ArrayList();
        Manger manger1 = new Manger();
        START h = new START();
        
        // array fot ID
        Employee.idArray.add(0);
         

    }
    
}
